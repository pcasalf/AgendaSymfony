<?php

namespace App\Entity;

use App\Repository\DiaryRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity(repositoryClass=DiaryRepository::class)
 * @UniqueEntity("email", message="El correo electronico ya se encuentra registrado")
 */
class Diary
{
    /**
     * @var string
     * Person contact enum
     */
    public const CONTACT_TYPE_PERSONAL = 'personal';

    /**
     * @var string
     * Professional contact enum
     */
    public const CONTACT_TYPE_PROFESSIONAL = 'professional';

    /**
     * @var array
     * Allowed contact types
     */
    public const ALLOWED_CONTACT_TYPE = [
        self::CONTACT_TYPE_PERSONAL,
        self::CONTACT_TYPE_PROFESSIONAL
    ];
    
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private ?int $id;

    /**
     * @var string $contactType
     * @ORM\Column(type="string", name="contact_type")
     */
    private string $contactType;

    /**
     * @var string $name
     * @ORM\Column(type="string", name="name")
     */
    private string $name;

    /**
     * @var string $lastName
     * @ORM\Column(type="string", name="last_name")
     */
    private string $lastName;

    /**
     * @var string $phone
     * @ORM\Column(type="string", name="phone")
     */
    private string $phone;

    /**
     * @var string $email
     * @ORM\Column(type="string", name="email", unique=true)
     */
    private string $email;

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getContactType(): string
    {
        return $this->contactType;
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * @return string
     */
    public function getPhone(): string
    {
        return $this->phone;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @param string $contactType
     */
    public function setContactType(string $contactType): void
    {
        $this->contactType = $contactType;
    }

    /**
     * @param string $name
     */
    public function setName(string $name): void
    {
        $this->name = $name;
    }

    /**
     * @param string $lastName
     */
    public function setLastName(string $lastName): void
    {
        $this->lastName = $lastName;
    }

    /**
     * @param string $phone
     */
    public function setPhone(string $phone): void
    {
        $this->phone = $phone;
    }

    /**
     * @param string $email
     */
    public function setEmail(string $email): void
    {
        $this->email = $email;
    }
}
