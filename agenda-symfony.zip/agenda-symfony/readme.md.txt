# Agenda 2.0 Pablo Casal Funcasta

_Se trata de un proyecto de Agenda realizada a traves del framework de php symfony, consiste en una página que almacena contactos en una base de datos dependiendo de como sea el contacto entrará en una agenda personal o en una agenda profesional donde despues podremos modificar el contacto, visualizarlo y borrarlo_

## Comenzar 🚀

Para comenzar la realizacion del proyecto tendremos que crear un proyecto symfony (symfony new my_project_name --full) y una base de datos. Si usamos Laragon tendremos que introducir localhost/nombreproyecto para asi acceder al proyecto para crear la base de datos php bin/console doctrine:database:create.  


## Requisitos 📋



 | Laragon | Symfony | CMD |
| ------------- | ------------- | ---------- |
| Carpeta del proyecto en Laragon  | Comando de creacón de la base de datos  | Ruta del proyecto |
| C:\laragon\www  | php bin/console doctrine:database:create | cd Laragon/ cd www |


## Instalacion ⚙️


_Colocar el proyecto en la ruta_

```
C:\laragon\www
```
_Crear la base de datos_

```
php bin/console doctrine:database:create
```
Crear las entidades

```
php bin/console make:entity NombreEntidad
```
Acceso por web 

```
localhost/Nombreproyecto/public
```

### Y las pruebas de estilo de codificación ⌨️


Al agregar un contacto veremos como se añade a la agenda que hemos elegido podremos entrar en la agenda y ver, editar y borrar el contacto


## Programas : 🛠

* [Symfony](https://symfony.com/) - El framework  usado
* [Laragon](https://laragon.org/) - Crea el Entorno de desarrollo
* [PHP](https://www.php.net/manual/es/intro-whatis.php) - Lenguaje de programacion utilizado
* [Visual Studio](https://visualstudio.microsoft.com/es/) - Aplicacion utilizada para desarrolar el proyecto

## Autores ✒️


Pablo Casal Funcasta - *Diary 2.0* 

 

## Licencia 📄

Apache License 2.0

## Como contribuir al proyecto 🎁

* Optimización del código 📢
* Buscar variantes alternativas 🤓
* Divulgacion del codigo ❤️.
